import pygame
import sys
import random

# Initialize pygame with MP3 support
pygame.init()
pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)  # Better for MP3
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Temple Run")
clock = pygame.time.Clock()

# Load villain voice sound (MP3)
try:
    villain_voice = pygame.mixer.Sound('sound/monster.mp3')
    villain_voice.set_volume(0.7)  # Reduce volume if too loud
except Exception as e:
    print(f"Warning: Could not load villain voice file - {e}")
    villain_voice = None

# [Rest of your code remains the same...]
# Keep all the existing Camera, Hero, BaboonMonk classes and main game loop
# Only the sound loading part above needs to change
# Camera setup
class Camera:
    def __init__(self):
        self.offset_x = 0
    
    def update(self, target):
        self.offset_x = target.rect.x

# Create camera
camera = Camera()

# Load and scale background
try:
    background = pygame.image.load('assets/background.jpg').convert()
    background = pygame.transform.scale(background, (screen_width, screen_height))
except:
    background = None

# Load and scale ground
try:
    ground_img = pygame.image.load('assets/base.png').convert_alpha()
    ground_img = pygame.transform.scale(ground_img, (screen_width, 100))
    ground_height = screen_height - ground_img.get_height()
except:
    ground_img = None
    ground_height = screen_height - 100  # Fallback value

class Hero:
    def __init__(self):
        # Load running animation frames
        self.run_frames = []
        for i in range(43):  # Assuming frames from 000 to 042
            try:
                frame = pygame.image.load(f"assets/run/1_{i:03d}.png").convert_alpha()
                frame = pygame.transform.scale(frame, (64, 64))
                self.run_frames.append(frame)
            except:
                # Create placeholder if image is missing
                placeholder = pygame.Surface((64, 64), pygame.SRCALPHA)
                placeholder.fill((255, 0, 0))  # Red placeholder
                self.run_frames.append(placeholder)
        
        # Load jump animation frames
        try:
            self.jump_frame = pygame.image.load("assets/jump/3_000.png").convert_alpha()
            self.jump_frame = pygame.transform.scale(self.jump_frame, (64, 64))
        except:
            self.jump_frame = pygame.Surface((64, 64), pygame.SRCALPHA)
            self.jump_frame.fill((0, 0, 255))  # Blue placeholder
        
        # Initialize animation variables
        self.current_frame = 0
        self.animation_speed = 0.60
        self.image = self.run_frames[0]
        self.rect = self.image.get_rect()
        self.rect.midbottom = (100, ground_height)
        self.speed = 5
        self.running = True
        self.is_jumping = False
        self.jump_velocity = 0
        self.gravity = 0.8
        self.jump_power = -15  # Negative because y increases downward
        self.facing_right = True  # Always facing right

    def update(self):
        if self.running:
            if not self.is_jumping:
                # Update running animation
                self.current_frame += self.animation_speed
                if self.current_frame >= len(self.run_frames):
                    self.current_frame = 0
                self.image = self.run_frames[int(self.current_frame)]
            else:
                # Use jump frame while jumping
                self.image = self.jump_frame
            
            # Handle jumping physics
            if self.is_jumping:
                self.rect.y += self.jump_velocity
                self.jump_velocity += self.gravity
                
                # Check if landed
                if self.rect.bottom >= ground_height:
                    self.rect.bottom = ground_height
                    self.is_jumping = False
                    self.jump_velocity = 0

    def jump(self):
        if not self.is_jumping:
            self.is_jumping = True
            self.jump_velocity = self.jump_power

class BaboonMonk:
    def __init__(self):
        # Load spritesheet
        try:
            self.spritesheet = pygame.image.load('assets/baboonMonk.png').convert_alpha()
        except:
            # Create placeholder if image missing
            self.spritesheet = pygame.Surface((256, 64), pygame.SRCALPHA)
            pygame.draw.rect(self.spritesheet, (200, 100, 0), (0, 0, 256, 64))
        
        # Animation properties - 2x size (128x128)
        self.frame_width = 64
        self.frame_height = 64
        self.scale_factor = 2
        self.frame_count = 4
        self.frames = self.load_frames()
        self.current_frame = 0
        self.animation_speed = 0.2
        
        # Positioning - start further behind hero
        self.rect = pygame.Rect(0, 0, self.frame_width * self.scale_factor, 
                               self.frame_height * self.scale_factor)
        self.rect.midbottom = (-200, ground_height)
        self.speed = 4
        self.chase_distance = 250
        
        # Voice properties
        self.has_played_intro = False
        self.last_voice_time = 0
        self.voice_cooldown = 4000  # 4 seconds between voice sounds
    
    def load_frames(self):
        frames = []
        for i in range(self.frame_count):
            frame = pygame.Surface((self.frame_width, self.frame_height), pygame.SRCALPHA)
            frame.blit(self.spritesheet, (0, 0), 
                      (i * self.frame_width, 0, self.frame_width, self.frame_height))
            frame = pygame.transform.scale(frame, 
                                         (self.frame_width * self.scale_factor, 
                                          self.frame_height * self.scale_factor))
            frames.append(frame)
        return frames
    
    def play_voice(self):
        current_time = pygame.time.get_ticks()
        if villain_voice and current_time - self.last_voice_time > self.voice_cooldown:
            villain_voice.play()
            self.last_voice_time = current_time
            # Randomize next cooldown between 3-5 seconds
            self.voice_cooldown = random.randint(3000, 5000)
    
    def update(self, hero):
        # Animation
        self.current_frame += self.animation_speed
        if self.current_frame >= self.frame_count:
            self.current_frame = 0
        
        # Face right (same as hero)
        self.image = self.frames[int(self.current_frame)]
        
        # Play intro voice when first appearing
        if not self.has_played_intro and self.rect.x > -150:
            if villain_voice:
                villain_voice.play()
            self.has_played_intro = True
        
        # Play voice occasionally during chase
        if abs(hero.rect.x - self.rect.x) < 400:  # When close to hero
            self.play_voice()
        
        # Chase logic - move right to catch up to hero
        distance_to_hero = hero.rect.x - self.rect.x
        
        if distance_to_hero > self.chase_distance:
            self.rect.x += self.speed * 1.3
        elif distance_to_hero > 100:
            self.rect.x += self.speed * 0.8
        
        # Reset if too far behind
        if self.rect.right < -200:
            self.rect.left = hero.rect.x - 500  # Spawn far behind hero
            self.has_played_intro = False  # Reset for new appearance
    
    def draw(self, surface):
        surface.blit(self.image, (self.rect.x - camera.offset_x + 100, self.rect.y))

def main():
    player = Hero()
    villain = BaboonMonk()
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player.jump()
        
        # Only allow right movement
        keys = pygame.key.get_pressed()
        if keys[pygame.K_RIGHT]:
            player.rect.x += player.speed
        
        # Update game objects
        player.update()
        villain.update(player)
        camera.update(player)
        
        # Calculate parallax positions
        bg_offset = -camera.offset_x % screen_width
        ground_offset = -camera.offset_x % screen_width
        
        # Draw everything
        if background:
            # Draw two background copies for seamless scrolling
            screen.blit(background, (bg_offset - screen_width, 0))
            screen.blit(background, (bg_offset, 0))
        else:
            screen.fill((135, 206, 235))  # Sky blue fallback
        
        if ground_img:
            # Draw two ground copies for seamless scrolling
            screen.blit(ground_img, (ground_offset - screen_width, ground_height))
            screen.blit(ground_img, (ground_offset, ground_height))
        else:
            pygame.draw.rect(screen, (139, 69, 19), (0, ground_height, screen_width, 100))
        
        # Draw characters
        screen.blit(player.image, (100, player.rect.y))  # Hero at fixed position
        villain.draw(screen)  # Villain position handled in its draw method
        
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()